/*
 * dynamic_allocator.c
 *
 *  Created on: Sep 21, 2023
 *      Author: HP
 */
#include <inc/assert.h>
#include <inc/string.h>
#include "../inc/dynamic_allocator.h"


//==================================================================================//
//============================== GIVEN FUNCTIONS ===================================//
//==================================================================================//

//=====================================================
// 1) GET BLOCK SIZE (including size of its meta data):
//=====================================================
uint32 get_block_size(void* va)
{
	struct BlockMetaData *curBlkMetaData = ((struct BlockMetaData *)va - 1) ;
	return curBlkMetaData->size ;
}

//===========================
// 2) GET BLOCK STATUS:
//===========================
int8 is_free_block(void* va)
{
	struct BlockMetaData *curBlkMetaData = ((struct BlockMetaData *)va - 1) ;
	return curBlkMetaData->is_free ;
}

//===========================================
// 3) ALLOCATE BLOCK BASED ON GIVEN STRATEGY:
//===========================================
void *alloc_block(uint32 size, int ALLOC_STRATEGY)
{
	void *va = NULL;
	switch (ALLOC_STRATEGY)
	{
	case DA_FF:
		va = alloc_block_FF(size);
		break;
	case DA_NF:
		va = alloc_block_NF(size);
		break;
	case DA_BF:
		va = alloc_block_BF(size);
		break;
	case DA_WF:
		va = alloc_block_WF(size);
		break;
	default:
		cprintf("Invalid allocation strategy\n");
		break;
	}
	return va;
}

//===========================
// 4) PRINT BLOCKS LIST:
//===========================
int freeeee=0;
void print_blocks_list(struct MemBlock_LIST list)
{
	cprintf("=========================================\n");
	struct BlockMetaData* blk ;
	cprintf("\nDynAlloc Blocks List:\n");
	LIST_FOREACH(blk, &list)
	{
		cprintf("(size: %d, isFree: %d)\n", blk->size, blk->is_free) ;
	}
	cprintf("=========================================\n");

}
//
////********************************************************************************//
////********************************************************************************//

//==================================================================================//
//============================ REQUIRED FUNCTIONS ==================================//
//==================================================================================//

//==================================
// [1] INITIALIZE DYNAMIC ALLOCATOR:
//==================================
struct MemBlock_LIST list;
bool is_initialized;
void initialize_dynamic_allocator(uint32 daStart, uint32 initSizeOfAllocatedSpace)
{

	//=========================================
	//DON'T CHANGE THESE LINES=================
	if (initSizeOfAllocatedSpace == 0)
		return ;
	is_initialized = 1;
	struct BlockMetaData *metaBlock;
		metaBlock=(struct BlockMetaData *)daStart;
		    metaBlock->is_free = 1;
		    metaBlock->size = initSizeOfAllocatedSpace;
	LIST_INIT(&list);
	LIST_INSERT_HEAD(&list, metaBlock);
	//=========================================
	//=========================================

	//TODO: [PROJECT'23.MS1 - #5] [3] DYNAMIC ALLOCATOR - initialize_dynamic_allocator()
	//panic("initialize_dynamic_allocator is not implemented yet");
}
struct BlockMetaData* create_block(struct BlockMetaData *generic_block,uint32 size,uint32 old_size)
{
	struct BlockMetaData* new = (struct BlockMetaData *)((int)generic_block + size+sizeOfMetaData());
    new->is_free = 1;
    new->size = old_size - (size+sizeOfMetaData());
    return new;
}
//=========================================
// [4] ALLOCATE BLOCK BY FIRST FIT:
//=========================================
int counter =0;
int dakhltelfree=0;
void *tiny_alloc_nf(struct BlockMetaData *newone,uint32 size){
	struct BlockMetaData * temp=newone;
	while(temp != NULL){
		 if(temp->is_free != 0 && temp->size >= (size + sizeOfMetaData()) ){
					   uint32 oldsize=temp->size;
					   struct BlockMetaData *newone;
					   temp->is_free = 0;
					   temp->size = size+sizeOfMetaData();
					   uint32 newsize =  oldsize - (size+sizeOfMetaData());
					   if(newsize <= 16){
						   temp->size += newsize;
						   void * add = (void *)((int)temp+(sizeOfMetaData()));
						  		   return add;
					   }
					   newone = create_block(temp,size,oldsize);
					   LIST_INSERT_AFTER(&list, temp,newone);

				   void * add = (void *)((int)temp+(sizeOfMetaData()));
				   return add;
			   }
		 temp = LIST_NEXT(temp);
	}
	return NULL;
}
void *alloc_block_FF(uint32 size)
{
	if(size == 0){
		return NULL;
	}
	if (!is_initialized)
	{
	uint32 required_size = size + sizeOfMetaData();
	uint32 da_start = (uint32)sbrk(required_size);
	//get new break since it's page aligned! thus, the size can be more than the required one
	uint32 da_break = (uint32)sbrk(0);
	initialize_dynamic_allocator(da_start, da_break - da_start);
	}

   struct BlockMetaData *f=LIST_FIRST(&list);
   if(LIST_EMPTY(&list)){
	   return NULL;
   }

   int hatb2aNF=1;
   if(freeeee){
	  // cprintf("i am after the free \n");
	   LIST_FOREACH(f, &list){

		  if(f->is_free == 1 && f->size >= size+sizeOfMetaData()&&f->prev_next_info.le_next!=NULL){
			  hatb2aNF=0;
		  }
	   }
	   if(hatb2aNF){
		   freeeee=0;
		  // cprintf("i am here \n");
	   }
	   else{
		   //print_blocks_list(list);
	   }
   }
   if(hatb2aNF != 0){
//	   cprintf("the block  in nf is %p \n",mostWanted);
	   struct BlockMetaData * nfBlock =tiny_alloc_nf(LIST_LAST(&list),size);
	   if(nfBlock != NULL)
	   return nfBlock;
	   struct BlockMetaData *new;
	               new=sbrk(size+sizeOfMetaData());
	               if( (int)new != -1){
	                 new->is_free = 0;
	                 new->size = size+sizeOfMetaData();
	                 LIST_INSERT_TAIL(&list, new);
	                 uint32 limitsofblock = (uint32)new+new->size;
	                 if(((uint32)sbrk(0)-limitsofblock) > sizeOfMetaData()){
	               	  struct BlockMetaData *newone;
	               	  newone = (struct BlockMetaData *)((uint32)new+new->size);
	               	  newone->is_free = 1;
	               	  newone->size = (uint32)sbrk(0)-limitsofblock;
	               	  LIST_INSERT_TAIL(&list, newone);
	                 }

	                  else new->size +=   (uint32)sbrk(0)-limitsofblock;

	                 return ((void *)new+sizeOfMetaData());

	      }
	               return NULL;

   }

   LIST_FOREACH(f, &list){
	   if(f->is_free != 0 && f->size >= (size + sizeOfMetaData()) ){
		   if(f->size == (size + sizeOfMetaData())){
			   f->is_free = 0;
			   f->size = size+sizeOfMetaData();
		   }
		   else{
			   uint32 oldsize=f->size;
			   struct BlockMetaData *newone;
			   f->is_free = 0;
			   f->size = size+sizeOfMetaData();
			   uint32 newsize =  oldsize - (size+sizeOfMetaData());
			   if(newsize <= 16){
				   f->size += newsize;
				   void * add = (void *)((int)f+(sizeOfMetaData()));
				  		   return add;
			   }
			   newone = create_block(f,size,oldsize);
			   //cprintf("the size of list is %d \n",LIST_SIZE(&list));
			   LIST_INSERT_AFTER(&list, f,newone);
		   }
		   void * add = (void *)((int)f+(sizeOfMetaData()));
		   return add;
	   }
   }
   		  struct BlockMetaData *new=sbrk(size+sizeOfMetaData());
            if( (int)new != -1){
              new->is_free = 0;
              new->size = size+sizeOfMetaData();
              LIST_INSERT_TAIL(&list, new);
              uint32 limitsofblock = (uint32)new+new->size;
              if(((uint32)sbrk(0)-limitsofblock) > sizeOfMetaData()){
            	  struct BlockMetaData *newone;
            	  newone = (struct BlockMetaData *)((uint32)new+new->size);
            	  newone->is_free = 1;
            	  newone->size = (uint32)sbrk(0)-limitsofblock;
            	  LIST_INSERT_TAIL(&list, newone);
              }
              return ((void *)new+sizeOfMetaData());

   }
            return NULL;

}
	//TODO: [PROJECT'23.MS1 - #6] [3] DYNAMIC ALLOCATOR - alloc_block_FF()
	//panic("alloc_block_FF is not implemented yet");


//=========================================
// [5] ALLOCATE BLOCK BY BEST FIT:
//=========================================
void *alloc_block_BF(uint32 size) {
    if (size == 0) {
        return NULL;
    }

    struct BlockMetaData *f = LIST_FIRST(&list);
    if (LIST_EMPTY(&list)) {
        return NULL;
    }
    uint32 perfectsize = 5*1024*1024;
    unsigned char found =0;
    struct BlockMetaData *perfectBlock= f;
    LIST_FOREACH(f,&list){
    	if(f->size >= size+sizeOfMetaData() && f->is_free == 1){
    		found = 1;
    		if(f->size < perfectsize){
    			perfectBlock = f;
    			perfectsize = f->size;
    		}
    	}
    }
    if(found==1){
    	if(perfectsize == size+sizeOfMetaData()){
    		perfectBlock->is_free = 0;
    	}
    	else{
    		uint32 oldsize = perfectBlock->size;
    		perfectBlock->is_free = 0;
    		perfectBlock->size = size+sizeOfMetaData();
    		uint32 newsize = oldsize- (size+sizeOfMetaData());
    		if(newsize <= 16){
    			perfectBlock->size += newsize;
    			return (void *)((int)perfectBlock + sizeOfMetaData());
    		}
    		struct BlockMetaData *newBlock = create_block(perfectBlock,size,oldsize);

    		 LIST_INSERT_AFTER(&list,perfectBlock,newBlock);
    	}
    	return (void *)((int)perfectBlock + sizeOfMetaData());
    }
    else{
    	struct BlockMetaData *new=sbrk(size+sizeOfMetaData());
    	            if( (int)new != -1){
    	              new->is_free = 0;
    	              new->size = size+sizeOfMetaData();
    	              LIST_INSERT_TAIL(&list, new);
    	              void * add = ((void *)new+sizeOfMetaData());
    	              return add;
    	            }
    }
    return NULL;
}


//=========================================
// [6] ALLOCATE BLOCK BY WORST FIT:
//=========================================
void *alloc_block_WF(uint32 size)
{
	panic("alloc_block_WF is not implemented yet");
	return NULL;
}

//=========================================
// [7] ALLOCATE BLOCK BY NEXT FIT:
//=========================================
void *alloc_block_NF(uint32 size)
{
	panic("alloc_block_NF is not implemented yet");
	return NULL;
}

//===================================================
// [8] FREE BLOCK WITH COALESCING:
//===================================================
int cccc=0;
void free_block(void *va)
{
	//print_blocks_list(list);
	if(va == NULL){
		return;
	}
	//print_blocks_list(list);
	dakhltelfree=1;
	freeeee=1;
//	if(cccc==0){
//		print_blocks_list(list);
//	}
	struct BlockMetaData *metaBlockk;
	metaBlockk=(struct BlockMetaData *)((int)va-16);
	int before=0,after=0;
	if(metaBlockk->prev_next_info.le_prev != NULL){
		if((metaBlockk->prev_next_info.le_prev)->is_free == 1){
			before=1;
		}
	}
	if(metaBlockk->prev_next_info.le_next != NULL){
			if((metaBlockk->prev_next_info.le_next)->is_free == 1){
				after=1;
			}
		}
	if(before==1 && after == 1){
		struct BlockMetaData *metaBlock1=(struct BlockMetaData *)(metaBlockk->prev_next_info.le_prev);
		struct BlockMetaData *metaBlock2=(struct BlockMetaData *)(metaBlockk->prev_next_info.le_next);
		uint32 size = metaBlockk->size + (metaBlock1)->size+(metaBlock2)->size;
		metaBlock1->size = size;
		metaBlock1->is_free = 1;
		metaBlockk->size = 0;
		metaBlockk->is_free =0;
		(metaBlock2)->is_free=0;
		(metaBlock2)->size=0;
		LIST_REMOVE(&list,metaBlock2);
		LIST_REMOVE(&list, metaBlockk);
			}
	else if(before==1){
		struct BlockMetaData *metaBlock1=(struct BlockMetaData *)(metaBlockk->prev_next_info.le_prev);
		uint32 size = metaBlockk->size + ((metaBlock1)->size);
		        metaBlock1->size = size;
				metaBlock1->is_free = 1;
		        metaBlockk->size = 0;
				metaBlockk->is_free =0;
				LIST_REMOVE(&list, metaBlockk);
	}
	else if(after == 1){
		struct BlockMetaData *metaBlock2=(struct BlockMetaData *)(metaBlockk->prev_next_info.le_next);
		uint32 size = metaBlockk->size +(metaBlock2)->size;
		         metaBlockk->size = size;
				metaBlockk->is_free = 1;
		        (metaBlock2)->is_free=0;
				(metaBlock2)->size=0;
				LIST_REMOVE(&list, metaBlock2);

	}
	else{
		metaBlockk->is_free = 1;
	}
	//print_blocks_list(list);
	//cprintf("list size: %d \n",LIST_SIZE(&list));
	//TODO: [PROJECT'23.MS1 - #7] [3] DYNAMIC ALLOCATOR - free_block()
	//panic("free_block is not implemented yet");
}

//=========================================
// [4] REALLOCATE BLOCK BY FIRST FIT:
//=========================================
void *realloc_block_FF(void* va, uint32 new_size)
{
	freeeee=1;
	if(new_size == 0 && va != NULL){
		free_block(va);
		return NULL;
	}
	else if(va == NULL){
		return alloc_block_FF(new_size);
	}
	struct BlockMetaData *metaBlockk;
	metaBlockk=(struct BlockMetaData *)((int)va-16);
	if(new_size + sizeOfMetaData() == metaBlockk->size){
	return va;
}
	struct BlockMetaData* nextBlock = LIST_NEXT(metaBlockk);
	if((new_size+sizeOfMetaData() )> metaBlockk->size){
		uint32 diffsize =  (new_size+sizeOfMetaData()) - metaBlockk->size;
		struct BlockMetaData *metaBlock2 = metaBlockk->prev_next_info.le_next;
		if(metaBlock2->size >= diffsize && metaBlock2->is_free == 1){
			metaBlockk->size = new_size+sizeOfMetaData();
			uint32 daOldSize = metaBlock2->size;
			metaBlock2->is_free =0;
			metaBlock2->size = 0;
			LIST_REMOVE(&list, metaBlock2);
			uint32 daNewSize =  daOldSize  - diffsize;
			if(daNewSize <= 16){
				            metaBlockk->size += daNewSize;
							return va;
						}
			metaBlock2 = (struct BlockMetaData *)((int)metaBlock2 + diffsize);
			metaBlock2->is_free =1;
			metaBlock2->size = daOldSize  - diffsize;
			LIST_INSERT_AFTER(&list,metaBlockk,metaBlock2);
			return va;
		}
		else{
			char* data = va;
			struct BlockMetaData * allocatedBlock=alloc_block_FF(new_size);
			if(allocatedBlock == NULL) return va;
			memcpy(allocatedBlock,va,(metaBlockk->size-sizeOfMetaData()));
			free_block(va);
			return allocatedBlock;
		}
	}
	else if((new_size+sizeOfMetaData() ) < metaBlockk->size){

		uint32 oldsize=metaBlockk->size;
		metaBlockk->size = new_size + sizeOfMetaData();
		struct BlockMetaData *newone;
		uint32 newsizeOfNewBlock =  oldsize - (new_size+sizeOfMetaData());
					   if(newsizeOfNewBlock <= 16){
						   metaBlockk->size  += newsizeOfNewBlock;
						   return va;
					   }
					   newone = create_block(metaBlockk,new_size,oldsize);
					   LIST_INSERT_AFTER(&list, metaBlockk,newone);
					   void * address = (void *) ((int)newone+sizeOfMetaData());
					   free_block(address);
					   return va;
	}
	//TODO: [PROJECT'23.MS1 - #8] [3] DYNAMIC ALLOCATOR - realloc_block_FF()
	//panic("realloc_block_FF is not implemented yet");
	return va;
}


